package main;
import java.util.List;
import java.util.Objects;

public class Order {
    private int order_id;
    private List<Product> products;

    public Order(int order_id, List<Product> products) {
        this.order_id = order_id;
        this.products = products;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
    
    public void addProduct(Product product) {
    	products.add(product);
    }
    
    public double calculateTotalOrderPrice() {
        double totalPrice = 0.0;
        for (Product product : products) {
            totalPrice += product.getProductPrice();
        }
        return totalPrice;
    }
    
    public double calculateAverageOrderPrice() {
        double totalPrice = 0.0;
        double totalQuantity = 0;
        for (Product product : products) {
            totalPrice += product.getProductPrice();
            totalQuantity+= product.getQuantity(); 
        }
        return totalPrice/totalQuantity;
    }
    
    public double calculateTotalQuantity() {
        int totalQuantity = 0;
        for (Product product : products) {
        	totalQuantity += product.getQuantity();
        }
        return totalQuantity;
    }

}