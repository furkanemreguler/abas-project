package main;
import java.util.Objects;

public class Product {
    private int product_id;
    private double price;
    private int quantity;

    public Product(int product_id, double price, int quantity) {
        this.product_id = product_id;
        this.price = price;
        this.quantity = quantity;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public double getProductPrice() {
        return this.price * this.quantity;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return product_id == product.product_id;
    }
    @Override
    public String toString() {
        return String.format("Product ID: %d, Quantity: %d, Average Price: %.2f", product_id, quantity, price);
    }
}
