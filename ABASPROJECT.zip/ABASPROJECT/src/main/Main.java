package main;
import java.util.ArrayList;


import java.util.List

;

public class Main {

	public static void main(String[] args) {
		
        List<Product> list1000 = new ArrayList<>();
        list1000.add(new Product(2000, 100.51, 12));
        list1000.add(new Product(2001, 200.00, 31));
        list1000.add(new Product(2002, 150.86, 22));
        list1000.add(new Product(2003, 250.00, 41));
        list1000.add(new Product(2004, 244.00, 55));
        
        List<Product> list1001 = new ArrayList<>();
        list1001.add(new Product(2001, 44.531, 88));
        list1001.add(new Product(2002, 88.11, 121));
        list1001.add(new Product(2004, 211.00, 74));
        list1001.add(new Product(2002, 88.11, 14));
        
		List<Product> list1002 = new ArrayList<>();
		list1002.add(new Product(2003, 12.1, 2));
        list1002.add(new Product(2004, 22.3, 3));
        list1002.add(new Product(2003, 12.1, 8));
        list1002.add(new Product(2002, 94.00, 16));
        list1002.add(new Product(2005, 44.1, 9));
        list1002.add(new Product(2006, 90.00, 19));

        List<Order> orders = new ArrayList<>();
        orders.add(new Order(1000, list1000));
        orders.add(new Order(1001, list1001));
        orders.add(new Order(1002, list1002));
        
        
        System.out.println("Step A:\n");

        double totalPrice = 0.0;

        for(Order order : orders) {
            double orderPrice = order.calculateTotalOrderPrice();
            System.out.println("Total Price for Order " + order.getOrder_id() + ": " + orderPrice);
            totalPrice += orderPrice;
        }

        System.out.println("Total Price of All Orders: " + totalPrice + "\n");
       
        System.out.println("Step B:\n");
        
        int totalQuantity = 0;
        
        for(Order order : orders) {
        	totalQuantity += order.calculateTotalQuantity();
            System.out.println("Average Price per Item for Order " + order.getOrder_id() + ": " + order.calculateAverageOrderPrice());
        }
        
        System.out.println("Average Price per Item for All Orders " + ": " + totalPrice/totalQuantity + "\n");
        
        System.out.println("Step C:\n");
        
        List<Product> allProducts = new ArrayList<>();
        
        for(Order order : orders)
        {
        	List<Product> products = order.getProducts();
        	for(Product product : products)
        	{
        		if(allProducts.contains(product))
        		{
                    int index = allProducts.indexOf(product);
                    Product existingProduct = allProducts.get(index);
                    int newQuantity = existingProduct.getQuantity() + product.getQuantity();
                    double newTotalPrice = existingProduct.getProductPrice() + product.getProductPrice();
                    existingProduct.setQuantity(newQuantity);
                    existingProduct.setPrice(newTotalPrice/newQuantity);
                    
        		}
        		else
        		{
        			allProducts.add(new Product(product.getProduct_id(), product.getPrice(),product.getQuantity()));
        		}
        	}
        }

        for(Product product : allProducts) {
            System.out.println(product);
        }       
        
        
        
        
        
        
        
        

    }
}
